# iot-demo

To run this application, execute the following commands:

  1. Install NPM modules
  
    ```
    $ cd iot-demo
    $ npm install
    ```
  2. Start the server

    ```
    $ cd server
    $ gulp dev
    ```

  3. Start the UI development server
    ```
    $ gulp dev
    ```
