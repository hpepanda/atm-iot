// (C) Copyright 2014-2015 Hewlett Packard Enterprise Development LP

import { createHistory, useQueries } from 'history';
export default useQueries(createHistory)();
