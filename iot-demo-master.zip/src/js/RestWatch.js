// (C) Copyright 2014-2015 Hewlett Packard Enterprise Development LP

var Rest = require('grommet/utils/Rest');

var RECONNECT_TIMEOUT = 5000; // 5s
var POLL_TIMEOUT = 10000; // 10s

var state = {
  ws: null,
  wsReady: false,
  timer: null,
  requests: [], // {message: , context: }
  nextRequestId: 1,
  initialized: false,
  socketUrl: null
};

var RestWatch = {

  _sendMessage: function(op, id, url, params) {
    console.log("sending message: " + op + " id:" + id);
    state.ws.send(JSON.stringify({
      op: op,
      id: id,
      url: url,
      params: params
    }));
  },

  _onOpen: function() {
    state.wsReady = true;
    // send any requests we have queued up
    state.requests.forEach(function(request) {
      this._sendMessage('start', request.id, request.url, request.params);
    }, this);
  },

  _onError: function(error) {
    console.log('!!! RestWatch _onError TODO', error);
  },

  _onMessage: function(event) {
    var message = JSON.parse(event.data);
    console.log("received message: " + message.id);
    // Figure out which message this corresponds to so we
    // know which action to deliver the response with.
    state.requests.some(function(request) {
      if (request.id === message.id) {
        request.handler(message.result);
      }
    });
  },

  _onClose: function() {
    console.log('!!! RestWatch _onClose');
    // lost connection, retry in a bit
    state.ws = null;
    state.wsReady = false;
    state.initialized = false;
    state.timer = setTimeout(this.initialize.bind(this), RECONNECT_TIMEOUT);
  },

  _getREST: function(request) {
    console.log('!!! RestWatch _getREST');
    request.pollBusy = true;
    Rest.get(request.url, request.params)
      .end(function(err, res) {
        console.log('!!! RestWatch end', err, res);
        if (err) {
          throw err;
        }

        if (res.ok) {
          request.handler(res.body);
        }
        request.pollBusy = false;
      });
  },

  _poll: function() {
    console.log('!!! RestWatch _poll');
    state.requests.forEach(function(request) {
      if (!request.pollBusy) {
        this._getREST(request);
      }
    });
  },

  initialize: function(socketUrl) {
    if (!state.initialized && !state.ws && this.available() && (state.socketUrl || socketUrl)) {
      state.socketUrl = state.socketUrl || socketUrl;
      state.ws = new WebSocket(state.socketUrl);
      state.ws.onopen = this._onOpen.bind(this);
      state.ws.onerror = this._onError.bind(this);
      state.ws.onmessage = this._onMessage.bind(this);
      state.ws.onclose = this._onClose.bind(this);
      state.initialized = true;
    }
  },

  available: function() {
    return ('WebSocket' in window || 'MozWebSocket' in window);
  },

  start: function(url, params, handler) {
    this.initialize();
    var requestId =state.nextRequestId;
    /*if (params && params.category == 'atms_alerts') {
      requestId = 2;
    } else if (params && params.category == 'critical_alerts') {
      requestId = 1;
    } else if (params && params.category == 'atms_history_details') {
      requestId = 3;
    }*/

    var request = {
      id: requestId,
      url: url,
      params: params,
      handler: handler
    };
    state.nextRequestId += 1;
    state.requests.push(request);

    if (state.wsReady) {
      this._sendMessage('start', request.id, request.url, request.params);
    } else if (!this.available()) {
      // no web sockets, fall back to polling
      this._getREST(request);
      clearTimeout(state.timer);
      state.timer = setTimeout(this._poll.bind(this), POLL_TIMEOUT);
    }
    return request.id;
  },

  stop: function(requestId) {
    state.requests = state.requests.filter(function(request) {
      if (request.id === requestId) {
        if (state.wsReady) {
          console.log("stop request: " + request.id + " category: " + request.params.category);
          this._sendMessage('stop', request.id, request.params.category);
        }
      } else {
        return true;
      }
    }, this);
  }
};

module.exports = RestWatch;
